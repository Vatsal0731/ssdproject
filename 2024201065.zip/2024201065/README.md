first extract the zip file 
que1) here we have taken data from access.log file and remove the line which contain string POST and 404 .
here we first give permission by using chmod +x 
then by using grep -i we reomve the lines 

que2) here we used awk function for the selection and summation of that particular colounm
