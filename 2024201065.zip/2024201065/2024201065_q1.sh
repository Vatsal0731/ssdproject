#!/bin/bash
grep -i "POST.*404" access.log

